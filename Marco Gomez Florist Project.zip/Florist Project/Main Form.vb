﻿Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Close()

    End Sub

    Private Sub x(sender As Object, e As KeyEventArgs) Handles btnExit.KeyDown

        Close()

    End Sub
End Class
